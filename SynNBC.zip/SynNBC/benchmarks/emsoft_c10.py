from learn.cegis_barrier import Cegis
from utils.Config_B import CegisConfig
import timeit
import torch
from benchmarks.Exampler_B import get_example_by_name


def main():
    activations = ['SKIP']  # 只有 "SQUARE","SKIP","MUL" 可选
    hidden_neurons = [15] * len(activations)
    example = get_example_by_name('emsoft_c10')
    start = timeit.default_timer()
    opts = {
        "ACTIVATION": activations,
        "EXAMPLE": example,
        "N_HIDDEN_NEURONS": hidden_neurons,
        "MULTIPLICATOR": True,  # 是否使用乘子
        "MULTIPLICATOR_NET": [],  # 乘子网络的每层结点数，设置为空表示乘子是一个可训练常数
        "MULTIPLICATOR_ACT": [],  # ReLU,SQUARE,MUL,SIKP,LINEAR,乘子网络每层的激活函数，由于最后一层不需要激活函数，所以个数要比MULTIPLICATOR_NET少一个。
        "BATCH_SIZE": 2000,
        "LEARNING_RATE": 0.2,
        "MARGIN": 2.0,  # 远离多少
        "LOSS_WEIGHT": (1.0, 1.0, 1.0),  # 分别是 init loss,unsafe loss,diffB loss 的权重,
        "SPLIT_D": True,  # 表示寻找反例的时候是否将区域划分为2^n个小区域，每个小区域分别寻找反例。
        "DEG": [2, 2, 2, 1],  # 分别表示验证sos时，init,unsafe,diffB,无约束乘子 的次数
        "R_b": 0.8,
        "LEARNING_LOOPS": 100,
        "CHOICE": [0, 0, 0]  # 对于找反例中使用minimize函数还是gurobi求解器寻找最值，0表示使用minimize函数，1表示使用
        # gurobi求解器，但是gurobi求解器不支持三次及以上的目标函数优化,三项分别对应init，unsafe，diffB求解最值的选择
    }
    Config = CegisConfig(**opts)
    c = Cegis(Config)
    c.solve()
    end = timeit.default_timer()
    print('Elapsed Time: {}'.format(end - start))


# B = 1.62051297020104*x1**2 + 2.10446996058963*x1*x2 + 1.34612765667713*x1*x3 + 2.34570105775868*x1*x4 - 1.42649944493507*x1*x5 + 0.236714409281646*x1*x6 + 0.181201730298194*x1*x7 + 0.531506295159316*x1*x8 + 0.474863312489116*x1*x9 - 10.1879370848136*x1 + 2.28409399735456*x2**2 + 2.8573855489514*x2*x3 + 1.98299990901986*x2*x4 - 0.481267182148138*x2*x5 + 0.16655726560713*x2*x6 - 1.07844167270999*x2*x7 + 0.600991212617456*x2*x8 + 0.451810572163759*x2*x9 - 10.3570162811964*x2 + 2.47821358506096*x3**2 + 2.92385272552472*x3*x4 - 1.70516206574969*x3*x5 + 0.167107823103999*x3*x6 - 0.898466699600456*x3*x7 + 1.02944576727448*x3*x8 + 1.01360728995601*x3*x9 - 12.7663010304169*x3 + 2.23500538953195*x4**2 - 0.0341568094213866*x4*x5 - 0.299348061719923*x4*x6 - 1.46782801265189*x4*x7 + 0.185317812342416*x4*x8 + 0.529656283868931*x4*x9 - 9.92845021087615*x4 + 0.446297175588995*x5**2 - 0.610606736108201*x5*x6 + 0.399955393480353*x5*x7 - 0.162462334236935*x5*x8 - 0.342665830478182*x5*x9 + 1.67994786581211*x5 + 0.422586050082028*x6**2 + 0.165464402621888*x6*x7 + 0.350127763260801*x6*x8 + 0.130905313016085*x6*x9 - 1.3670469007578*x6 + 0.70095089016406*x7**2 - 0.729161202689489*x7*x8 - 0.226791704959064*x7*x9 + 0.927707090162596*x7 + 0.185178646259061*x8**2 + 0.292895664113886*x8*x9 - 2.88069246495791*x8 + 0.252614363195707*x9**2 - 2.5606606140022*x9 + 20.6684005395167

if __name__ == '__main__':
    torch.manual_seed(167)
    main()
