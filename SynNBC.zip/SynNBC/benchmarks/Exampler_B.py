import numpy as np


class Example():
    def __init__(self, n, D_zones, I_zones, U_zones, f, name):
        if len(D_zones) != n:
            raise ValueError('{}的维度不对'.format('D_zones'))
        if len(I_zones) != n:
            raise ValueError('{}的维度不对'.format('I_zones'))
        if len(U_zones) != n:
            raise ValueError('{}的维度不对'.format('U_zones'))
        if len(f) != n:
            raise ValueError('{}的维度不对'.format('f'))
        self.n = n  # 变量个数
        self.D_zones = np.array(D_zones)  # 不变式区域
        self.I_zones = np.array(I_zones)  # 初始区域
        self.U_zones = np.array(U_zones)  # 非安全区域
        self.f = f  # 微分方程
        self.name = name  # 名字或者标识符


examples = {
    1: Example(
        n=7,
        D_zones=[[-2, 2]] * 7,
        I_zones=[[-1.01, -0.99]] * 7,
        U_zones=[[1.8, 2]] * 7,
        f=[
            lambda x: -0.4 * x[0] + 5 * x[2] * x[3],
            lambda x: 0.4 * x[0] - x[1],
            lambda x: x[1] - 5 * x[2] * x[3],
            lambda x: 5 * x[4] * x[5] - 5 * x[2] * x[3],
            lambda x: -5 * x[4] * x[5] + 5 * x[2] * x[3],
            lambda x: 0.5 * x[6] - 5 * x[4] * x[5],
            lambda x: -0.5 * x[6] + 5 * x[4] * x[5]
        ],
        name='test_7dim'
    ),
    2: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[0, 1], [1, 2]],
        U_zones=[[-2, -0.5], [-0.75, 0.75]],
        f=[
            lambda x: x[1] + 2 * x[0] * x[1],
            lambda x: -x[0] - x[1] ** 2 + 2 * x[0] ** 2
        ],
        name='barr_1'
    ),
    3: Example(
        n=4,
        D_zones=[[-2, 2]] * 4,
        I_zones=[[0.5, 1.5]] * 4,
        U_zones=[[-2.4, -1.6]] * 4,
        f=[lambda x: x[0],
           lambda x: x[1],
           lambda x: x[2],
           lambda x: - 3980 * x[3] - 4180 * x[2] - 2400 * x[1] - 576 * x[0]
           ],
        name='hi_ord_4'
    ),
    4: Example(
        n=2,
        D_zones=[[1, 5]] * 2,
        I_zones=[[4, 4.5], [0.9, 1.1]],
        U_zones=[[1, 2], [2, 3]],
        f=[lambda x: -5.5 * x[1] + x[1] * x[1],
           lambda x: 6 * x[0] - x[0] * x[0],
           ],
        name='emsoft_c1'
    ),
    5: Example(
        n=3,
        D_zones=[[-2, 2]] * 3,
        I_zones=[[-0.25, 0.75], [-0.25, 0.75], [-0.75, 0.25]],
        U_zones=[[1, 2], [-2, -1], [-2, -1]],
        f=[lambda x: -x[1],
           lambda x: -x[2],
           lambda x: -x[0] - 2 * x[1] - x[2] + x[0] * x[0] * x[0],
           ],
        name='emsoft_c2'
    ),
    6: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[-1 / 5, 1 / 5], [3 / 10, 7 / 10]],
        U_zones=[[-2, -1], [-2, -1]],
        f=[lambda x: -x[0] + 2 * x[0] * x[0] * x[0] * x[1] * x[1],
           lambda x: -x[1]
           ],
        name='emsoft_c3'
    ),
    7: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[-1, 0], [-1, 0]],
        U_zones=[[1, 2], [1, 2]],
        f=[lambda x: -1 + x[0] * x[0] + x[1] * x[1],
           lambda x: 5 * (-1 + x[0] * x[1])
           ],
        name='emsoft_c4'
    ),
    8: Example(
        n=2,
        D_zones=[[-3, 3]] * 2,
        I_zones=[[-1 / 5, 1 / 5], [-1 / 5, 1 / 5]],
        U_zones=[[2, 3], [2, 3]],
        f=[lambda x: x[0] - x[0] * x[0] * x[0] + x[1] - x[0] * x[1] * x[1],
           lambda x: -x[0] + x[1] - x[0] * x[0] * x[1] - x[1] * x[1] * x[1]
           ],
        name='emsoft_c5'
    ),
    9: Example(
        n=2,
        D_zones=[[-1, 1]] * 2,
        I_zones=[[-1 / 10, 1 / 10], [-1 / 10, 1 / 10]],
        U_zones=[[1 / 2, 1], [1 / 2, 1]],
        f=[lambda x: -2 * x[0] + x[0] * x[0] + x[1],
           lambda x: x[0] - 2 * x[1] + x[1] * x[1]
           ],
        name='emsoft_c6'
    ),
    10: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[-3 / 2, -1 / 2], [-3 / 2, -1 / 2]],
        U_zones=[[-1 / 2, 1 / 2], [1 / 2, 3 / 2]],
        f=[lambda x: -x[0] + x[0] * x[1],
           lambda x: -x[1]
           ],
        name='emsoft_c7'
    ),
    11: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[-1 / 4, 1 / 4], [3 / 4, 3 / 2]],
        U_zones=[[1, 2], [1, 2]],
        f=[lambda x: -x[0] + 2 * x[0] * x[0] * x[1],
           lambda x: -x[1]
           ],
        name='emsoft_c8'
    ),
    12: Example(
        n=7,
        D_zones=[[-2, 2]] * 7,
        I_zones=[[-1.01, -0.99]] * 7,
        U_zones=[[1.8, 2]] * 7,
        f=[lambda x: -0.4 * x[0] + 5 * x[2] * x[3],
           lambda x: 0.4 * x[0] - x[1],
           lambda x: x[1] - 5 * x[2] * x[3],
           lambda x: 5 * x[4] * x[5] - 5 * x[2] * x[3],
           lambda x: -5 * x[4] * x[5] + 5 * x[2] * x[3],
           lambda x: 0.5 * x[6] - 5 * x[4] * x[5],
           lambda x: -0.5 * x[6] + 5 * x[4] * x[5]
           ],
        name='emsoft_c9'
    ),
    13: Example(
        n=9,
        D_zones=[[-2, 2]] * 9,
        I_zones=[[0.99, 1.01]] * 9,
        U_zones=[[1.8, 2]] * 9,
        f=[
            lambda x: 3 * x[2] - x[0] * x[5],
            lambda x: x[3] - x[1] * x[5],
            lambda x: x[0] * x[5] - 3 * x[2],
            lambda x: x[1] * x[5] - x[3],
            lambda x: 3 * x[2] + 5 * x[0] - x[4],
            lambda x: 5 * x[4] + 3 * x[2] + x[3] - x[5] * (x[0] + x[1] + 2 * x[7] + 1),
            lambda x: 5 * x[3] + x[1] - 0.5 * x[6],
            lambda x: 5 * x[6] - 2 * x[5] * x[7] + x[8] - 0.2 * x[7],
            lambda x: 2 * x[5] * x[7] - x[8]
        ],
        name='emsoft_c10'
    ),
    14: Example(
        n=2,
        D_zones=[[-3.5, 2], [-2, 1]],
        I_zones=[[1, 2], [-0.5, 0.5]],
        U_zones=[[-1.4, -0.6]] * 2,
        f=[
            lambda x: x[1],
            lambda x: -x[0] - x[1] + 1 / 3.0 * x[0] ** 3
        ],
        name='barr_2'
    ),
    15: Example(
        n=6,
        D_zones=[[-2, 2]] * 6,
        I_zones=[[0.5, 1.5]] * 6,
        U_zones=[[-2, -1.6]] * 6,
        f=[
            lambda x: x[1],
            lambda x: x[2],
            lambda x: x[3],
            lambda x: x[4],
            lambda x: x[5],
            lambda x: - 800 * x[5] - 2273 * x[4] - 3980 * x[3] - 4180 * x[2] - 2400 * x[1] - 576 * x[0]
        ],
        name='hi_ord_6'
    ),
    16: Example(
        n=8,
        D_zones=[[-2, 2]] * 8,
        I_zones=[[0.5, 1.5]] * 8,
        U_zones=[[-2, -1.6]] * 8,
        f=[
            lambda x: x[1],
            lambda x: x[2],
            lambda x: x[3],
            lambda x: x[4],
            lambda x: x[5],
            lambda x: x[6],
            lambda x: x[7],
            lambda x: -20 * x[7] - 170 * x[6] - 800 * x[5] - 2273 * x[4] - 3980 * x[3] - 4180 * x[2] - 2400 * x[
                1] - 576 * x[0]
        ],
        name='hi_ord_8'
    ),
    17: Example(
        n=12,
        D_zones=[[-2, 2]] * 12,
        I_zones=[[-0.1, 0.1]] * 12,
        U_zones=[[0, 0.5]] * 3 + [[0.5, 1.5]] * 4 + [[-1.5, -0.5]] + [[0.5, 1.5]] * 2 + [[-1.5, -0.5]] + [[0.5, 1.5]],
        f=[
            lambda x: x[3],
            lambda x: x[4],
            lambda x: x[5],
            lambda x: -7253.4927 * x[0] + 1936.3639 * x[10] - 1338.7624 * x[3] + 1333.3333 * x[7],
            lambda x: -1936.3639 * x[9] - 7253.4927 * x[1] - 1338.7624 * x[4] - 1333.3333 * x[6],
            lambda x: -769.2308 * x[2] - 770.2301 * x[5],
            lambda x: x[9],
            lambda x: x[10],
            lambda x: x[11],
            lambda x: 9.81 * x[1],
            lambda x: -9.81 * x[0],
            lambda x: -16.3541 * x[11] - 15.3846 * x[8]
        ],
        name='emsoft_c11'
    ),
    18: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[-0.1, 0.1]] * 2,
        U_zones=[[0, 0.5], [0.5, 1.5]],
        f=[
            lambda x: x[1],
            lambda x: -769.2308 * x[0] - 770.2301 * x[1],
        ],
        name='emsoft_c11_2_1'

    ),
    19: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[-0.1, 0.1]] * 2,
        U_zones=[[0.5, 1.5], [0.5, 1.5]],
        f=[
            lambda x: x[1],
            lambda x: -16.3541 * x[1] - 15.3846 * x[0]
        ],
        name='emsoft_c11_2_2',
    ),
    20: Example(
        n=4,
        D_zones=[[-2, 2]] * 4,
        I_zones=[[-0.1, 0.1]] * 4,
        U_zones=[[0, 0.5], [0.5, 1.5], [-1.5, -0.5], [-1.5, -0.5]],
        f=[
            lambda x: x[1],
            lambda x: -7253.4927 * x[0] + 1936.3639 * x[3] - 1338.7624 * x[1] + 1333.3333 * x[2],
            lambda x: x[3],
            lambda x: -9.81 * x[0],
        ],
        name='emsoft_c11_4_1',
    ),
    21: Example(
        n=4,
        D_zones=[[-2, 2]] * 4,
        I_zones=[[-0.1, 0.1]] * 4,
        U_zones=[[0, 0.5], [0.5, 1.5], [0.5, 1.5], [-1.5, 0.5]],
        f=[
            lambda x: x[1],
            lambda x: -1936.3639 * x[3] - 7253.4927 * x[0] - 1338.7624 * x[1] - 1333.3333 * x[2],
            lambda x: x[3],
            lambda x: 9.81 * x[0],
        ],
        name='emsoft_c11_4_2',
    ),
    24: Example(
        n=10,
        D_zones=[[-2, 2]] * 10,
        I_zones=[[-0.1, 0.1]] * 10,
        U_zones=[[0, 0.5], [0, 0.5], [0, 0.5], [0.5, 1.5], [0.5, 1.5], [0.5, 1.5], [0.5, 1.5], [-1.5, -0.5], [0.5, 1.5],
                 [-1.5, -0.5]],
        f=[
            lambda x: x[3],
            lambda x: x[4],
            lambda x: x[5],
            lambda x: -7253.4927 * x[0] + 1936.3639 * x[9] - 1338.7624 * x[3] + 1333.3333 * x[7],
            lambda x: -1936.3639 * x[8] - 7253.4927 * x[1] - 1338.7624 * x[4] - 1333.3333 * x[6],
            lambda x: -769.2308 * x[2] - 770.2301 * x[5],
            lambda x: x[8],
            lambda x: x[9],
            lambda x: 9.81 * x[1],
            lambda x: -9.81 * x[0]
        ],
        name='dim_12_10',
    ),
    25: Example(
        n=8,
        D_zones=[[-2, 2]] * 8,
        I_zones=[[-0.1, 0.1]] * 8,
        U_zones=[[0, 0.5], [0, 0.5], [0.5, 1.5], [0.5, 1.5], [0.5, 1.5], [-1.5, -0.5], [0.5, 1.5],
                 [-1.5, -0.5]],
        f=[

            lambda x: x[2],
            lambda x: x[3],
            lambda x: -7253.4927 * x[0] + 1936.3639 * x[7] - 1338.7624 * x[2] + 1333.3333 * x[5],
            lambda x: -1936.3639 * x[6] - 7253.4927 * x[1] - 1338.7624 * x[3] - 1333.3333 * x[4],
            lambda x: x[6],
            lambda x: x[7],
            lambda x: 9.81 * x[1],
            lambda x: -9.81 * x[0]
        ],
        name='dim_12_8',
    ),
    26: Example(
        n=2,
        D_zones=[[-2, 2]] * 2,
        I_zones=[[0, 1], [1, 2]],
        U_zones=[[-2, -0.5], [-0.75, 0.75]],
        f=[
            lambda x: x[1] + 2 * x[0] * x[1],
            lambda x: -x[0] - x[1] ** 2 + 2 * x[0] ** 2
        ],
        name='plot'
    ),
}


def get_example_by_id(id: int):
    return examples[id]


def get_example_by_name(name: str):
    for ex in examples.values():
        if ex.name == name:
            return ex
    raise ValueError('没有找到{}这个例子'.format(name))


if __name__ == '__main__':
    print(get_example_by_id(1))
