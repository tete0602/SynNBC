import sympy as sp
import numpy as np
from matplotlib import pyplot as plt
from plots.plot_fcns import plot_circle_sets, vector_field, plot_square_sets, plot_parabola
from plots.plot_barriers import init_plot_ground, barrier_3d, set_3d_labels_and_title, set_2d_labels_and_title
from benchmarks.Exampler_B import get_example_by_name
from verify.CounterExampleFind_B import CounterExampleFinder
from matplotlib.patches import Rectangle

plt.figure()
fig = plt.figure()
ax = fig.add_subplot(111)

zones = np.array([[-2, 2], [-1.5, 1.5]])
r = 0.4
times = 1 / (1 - r)
L = zones[:, 1] - zones[:, 0]
print(zones[:2, 0], *(zones[:2, 1] - zones[:2, 0]))
p = Rectangle(zones[:2, 0], *(zones[:2, 1] - zones[:2, 0]), linestyle='-', color='g', linewidth=1.5, fill=False,
              label='target bound')
ax.add_patch(p)

set_2d_labels_and_title('$x_1$', '$x_2$', '')
points = (np.random.random([100, 2]) - 0.5) * L
# plt.scatter(points[:,0],points[:,1],s=10,c='y')

p = Rectangle(zones[:2, 0] * times, *((zones[:2, 1] - zones[:2, 0]) * times), linestyle='--', color='r', linewidth=1.5,
              fill=False, label='$r_b$ times bound')
ax.add_patch(p)
points = points * times
plt.scatter(points[:, 0], points[:, 1], s=10, c='y')

# my_x_ticks = np.arange(-3, 4.5, 0.5)
# my_y_ticks = np.arange(-3, 4.5, 0.5)
# plt.xticks(my_x_ticks)
# plt.yticks(my_y_ticks)
plt.xlim(-4, 4)
plt.ylim(-4, 4)
plt.legend()
plt.savefig('img/bound_enhance_1.pdf')
plt.show()

fig = plt.figure()
ax = fig.add_subplot(111)
ax.add_patch(
    Rectangle(zones[:2, 0], *(zones[:2, 1] - zones[:2, 0]), linestyle='-', color='g', linewidth=1.5, fill=False,
              label='target bound'))
set_2d_labels_and_title('$x_1$', '$x_2$', '')
for i in range(2):
    points[:, i] = np.clip(points[:, i], *zones[i])
plt.scatter(points[:, 0], points[:, 1], s=10, c='y')
plt.xlim(-4, 4)
plt.ylim(-4, 4)
plt.legend()
plt.savefig('img/bound_enhance_2.pdf')
plt.show()
