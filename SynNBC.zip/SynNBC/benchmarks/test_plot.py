from plots.plot_barriers import init_plot_ground
from Exampler_B import get_example_by_name

ex=get_example_by_name('barr_1')
init_plot_ground(2,)