from learn.cegis_barrier import Cegis
from utils.Config_B import CegisConfig
import timeit
import torch
from benchmarks.Exampler_B import get_example_by_name
from plots.plot_barriers import plot_benchmark2d


def main():
    activations = ['SKIP']
    hidden_neurons = [5] * len(activations)
    example = get_example_by_name('emsoft_c11')
    start = timeit.default_timer()
    opts = {
        "ACTIVATION": activations,
        "EXAMPLE": example,
        "N_HIDDEN_NEURONS": hidden_neurons,
        "MULTIPLICATOR": True,  # 是否使用乘子
        "MULTIPLICATOR_NET": [],  # 乘子网络的每层结点数，设置为空表示乘子是一个可训练常数
        "MULTIPLICATOR_ACT": [],  # 乘子网络每层的激活函数，由于最后一层不需要激活函数，所以个数要比MULTIPLICATOR_NET少一个。
        "BATCH_SIZE": 10000,
        "LEARNING_RATE": 0.05,
        "MARGIN": 5,  # 远离多少
        "LOSS_WEIGHT": (100.0, 1000.0, 1.0),  # 分别是 init loss,unsafe loss,diffB loss 的权重,
        "SPLIT_D": True,  # 表示寻找反例的时候是否将区域划分为2^n个小区域，每个小区域分别寻找反例。
        "DEG": [2, 0, 0, 0],  # 分别表示验证sos时，init,unsafe,diffB,无约束乘子 的次数
        "R_b": 0.99,
        "LEARNING_LOOPS": 100,
        "CHOICE": [0, 0, 0]  # 对于找反例中使用minimize函数还是gurobi求解器寻找最值，0表示使用minimize函数，1表示使用
        # gurobi求解器，但是gurobi求解器不支持三次及以上的目标函数优化,三项分别对应init，unsafe，diffB求解最值的选择
    }
    Config = CegisConfig(**opts)
    c = Cegis(Config)
    c.generate_data()
    c.solve()
    end = timeit.default_timer()
    print('Elapsed Time: {}'.format(end - start))
    if c.n == 2:
        plot_benchmark2d(example, c.Learner.net.get_barrier())


if __name__ == '__main__':
    torch.manual_seed(167)
    main()
