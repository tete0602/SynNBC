from learn.cegis_barrier import Cegis
from utils.Config_B import CegisConfig
import timeit
import torch
from benchmarks.Exampler_B import get_example_by_name

def main():
    activations = ['SKIP','SKIP']  # 只有 "SQUARE","SKIP","MUL" 可选
    hidden_neurons = [20] * len(activations)
    example=get_example_by_name('test_7dim')
    start = timeit.default_timer()
    opts = {
        "ACTIVATION": activations,
        "EXAMPLE":example ,
        "N_HIDDEN_NEURONS": hidden_neurons,
        "MULTIPLICATOR": True, #是否使用乘子
        "BATCH_SIZE" : 5000,
        "LEARNING_RATE":0.05,
        "LOSS_WEIGHT":(1.0,1.0,1.0) #分别是 init loss,unsafe loss,diffB loss 的权重
    }
    Config=CegisConfig(**opts)
    c = Cegis(Config)
    c.generate_data()
    c.solve()
    end = timeit.default_timer()
    print('Elapsed Time: {}'.format(end - start))

    """
    todo: plot 2d 
    """
    # plotting -- only for 2-d systems
    # if state[CegisStateKeys.found]:
    #     plot_darboux_bench(np.array(vars), state[CegisStateKeys.V])

if __name__ == '__main__':
    torch.manual_seed(167)
    main()
