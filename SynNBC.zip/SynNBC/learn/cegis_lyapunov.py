import torch
import numpy as np
from utils.Config_V import CegisConfig
from learn.net_V import Learner
from verify.CounterExampleFind_V import CounterExampleFinder
from verify.SosVerify_V import SosValidator_V


class Cegis:

    def __init__(self, config: CegisConfig):
        n = config.EXAMPLE.n
        self.ex = config.EXAMPLE
        self.n = n
        self.f = config.EXAMPLE.f
        self.D_zones = np.array(config.EXAMPLE.D_zones, dtype=np.float32).T
        self.batch_size = config.BATCH_SIZE
        self.learning_rate = config.LEARNING_RATE
        self.Learner = Learner(config)

        self.optimizer = config.OPT(self.Learner.net.parameters(), lr=self.learning_rate)
        self.CounterExampleFinder = CounterExampleFinder(config.EXAMPLE, config)

        self.max_cegis_iter = 100
        self.DEG = config.DEG

    def solve(self):

        S, Sdot = self.generate_data()
        # the CEGIS loop
        deg = self.DEG
        for i in range(self.max_cegis_iter):
            self.Learner.learn(self.optimizer, S, Sdot)
            V = self.Learner.net.get_lyapunov()

            print(f'iter: {i + 1} \nV = {V}')

            Sos_Validator = SosValidator_V(self.ex, V)
            if Sos_Validator.SolveAll(deg=deg):
                print('SOS验证通过！')
                break

            # 在李导数的反例时，将B(x)==0 的条件放松为 |B(x)|<=margin 来寻找反例，所以存在反例并不能说明一定不满足sos
            samples, satisfy = self.CounterExampleFinder.get_counter_example(V)
            if satisfy:
                print('没有找到反例！')

            if satisfy:
                # 如果没找到反例，但sos未通过，可能是乘子次数过低
                deg[1] += 2

            S, Sdot = self.add_ces_to_data(S, Sdot, samples)
            print('-' * 200)

    def add_ces_to_data(self, S, Sdot, ces):

        print(f'加入 {len(ces)} 个反例！')
        S = torch.cat([S, ces], dim=0).detach()
        dot_ces = self.x2dotx(ces)
        Sdot = torch.cat([Sdot, dot_ces], dim=0).detach()

        return S, Sdot

    def generate_data(self):

        D_len = self.D_zones[1] - self.D_zones[0]

        # 让更多的样本点落到边界上
        size = 2
        S = torch.clip((torch.rand([self.batch_size, self.n]) - 0.5) * size, -0.5, 0.5) + 0.5
        S = S * D_len + self.D_zones[0]

        Sdot = self.x2dotx(S)

        return S, Sdot

    def x2dotx(self, X):  # todo 改为map映射会快一点
        f_x = []
        for x in X:
            f_x.append([self.f[i](x) for i in range(self.n)])
        return torch.Tensor(f_x)


if __name__ == '__main__':
    pass
